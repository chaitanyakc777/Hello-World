﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldAPI1.Models
{
    public class HelloWorld
    {
        public string strMessage { get; set; }

    }
}