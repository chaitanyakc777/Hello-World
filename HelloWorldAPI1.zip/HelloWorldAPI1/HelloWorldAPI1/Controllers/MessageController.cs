﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HelloWorldAPI1.Controllers
{
    public class MessageController : ApiController
    {
        HelloWorldAPI1.Models.HelloWorld[] helloworld = new HelloWorldAPI1.Models.HelloWorld[]
        {
            new Models.HelloWorld{strMessage = "Hello World" }
        };

        public IEnumerable<Models.HelloWorld> GetMessage()
        {
            return helloworld;
        }

    }
}
